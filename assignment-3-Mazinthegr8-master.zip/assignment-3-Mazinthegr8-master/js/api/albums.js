// base url defined below.
const BASE_URL = `http://localhost:5000`

// api requests functions below.
export function getAlbums(search) {
    let result = fetch(`http://localhost:5000/topAlbums?q=${search}`)
   .then( (response) => {
    
        return response.json();
    })
    .then( (postData) => {
        return postData;
     });
    
   return result;
}
