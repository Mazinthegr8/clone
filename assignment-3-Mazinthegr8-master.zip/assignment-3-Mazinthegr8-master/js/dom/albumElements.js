/*

<li class="list-group-item d-flex justify-content-between align-items-start">
    <div class="ms-2 me-auto">
        <div class="fw-bold">
           album name
            <span class="badge bg-primary rounded-pill">rating</span>
        </div>
        <span> artist name </span>
    </div>
    <button type="button" class="btn btn-success">Add to My Albums</button>
</li>


*/

// create the function "createAlbumItem" here
export function createListItem(albumInfo) {
    // let data = getAlbums()
    const albumName = albumInfo.album
    const artistName = albumInfo.artistName
    const rating = albumInfo.averageRating
    console.log(albumName)
    // Create list item element
    const listItem = document.createElement('li');
    listItem.classList.add('list-group-item','d-flex','justify-content-between', 'align-items-start')
    let cardbody = document.createElement('div');
    cardbody.classList.add('ms-2', 'me-auto');
    let albumDiv = document.createElement('div');
    albumDiv.classList.add('fw-bold');
    let albumRating = document.createElement('span')
    albumRating.classList.add('badge', 'bg-primary', 'rounded-pill');
    albumRating.append(rating)
    let artistNameSpan = document.createElement('span');
    artistNameSpan.append(artistName)
    let button = document.createElement('button')
    button.setAttribute('type', 'button')
    button.classList.add('btn', 'btn-success')
    button.append('Add To My Albums')
    // Set text content of the list item
    listItem.append(cardbody,button)
    cardbody.append(albumDiv,artistNameSpan)
    albumDiv.append(albumName,albumRating)
    // Return the created list item
    return listItem;
}

