/*
HTML for table rows.
<tr>
  <td>ALBUM NAME HERE</td>
  <td>RELEASE DATE HERE</td>
  <td>ARTIST NAME HERE</td>
  <td>GENRE HERE</td>
  <td>AVERAGE RATING HERE</td>
  <td>NUMBER OF RATINGS HERE</td>
</tr>
*/

/*
Import bootstrap then your css below
*/
import 'bootstrap/dist/css/bootstrap.min.css'
import '../css/cover.css'


// Javascript imports below
import { getAlbums } from '../js/api/albums.js'
import { createListItem } from './dom/albumElements.js';
// For Bonus part (do not remove)
let searchedAlbums = []


// your code below here.

// part 1: navigation
let tabNavigator = document.querySelector("#album-tab-navigation")
let searchAlbumTab = document.querySelector("#search-album-tab")
let myAlbumsTab = document.querySelector("#my-albums-tab")
let searchAlbumsLink = tabNavigator.children[0].children[0];
console.log(searchAlbumsLink);
let myAlbumsLink = tabNavigator.children[1].children[0];
console.log(myAlbumsLink);
tabNavigator.addEventListener('click', (event) => {
  let tabName = event.target;
  console.log(tabName.textContent);
  if (tabName.textContent === 'Search Albums') {
    tabName.classList.add('active');
    myAlbumsLink.classList.remove('active');
    searchAlbumTab.classList.remove('d-none');
    myAlbumsTab.classList.add('d-none');
    console.log(myAlbumsTab);
    console.log(tabName);
  }
  console.log(tabName.textContent)
  if (tabName.textContent === 'My Albums') {
    console.log(tabName);
    tabName.classList.add('active');
    console.log('entered')
    searchAlbumsLink.classList.remove('active');
    myAlbumsTab.classList.remove('d-none');
    searchAlbumTab.classList.add('d-none');

  }
  console.log(tabName)
})
// part 2: search albums
sumbitButton = document.querySelector('#search-album-form')
result = document.querySelector('#searched-albums-list')
sumbitButton.addEventListener('submit', (event) => {
  event.preventDefault()
  while (result.firstChild) {
    result.removeChild(result.firstChild)
  }
  getAlbums(document.querySelector('#query-input').value)
    .then(albums => {
      albums.forEach((album) => {
        console.log(albums)
        console.log(album)
      const listItem = createListItem(album)
      
      result.append(listItem)
      })
    }

    );



})

// part 3: add albums to my albums
//add event lister for click on entire list element 
//check if button is clicked
//if y append to other div and remove button
result.addEventListener('click',(event) => {
  console.log('print')
  if (event.target.classList.contains('btn-success')) {
    console.log(event.target.parentNode)
    const ParentList = event.target.parentNode;
    let albumlist = document.querySelector('#my-albums')
    albumlist.append(ParentList)
    event.target.remove()
  }
})

// bonus part

