[![Review Assignment Due Date](https://classroom.github.com/assets/deadline-readme-button-24ddc0f5d75046c5622901739e7c5dd533143b0c8e959d652212380cedb1ea36.svg)](https://classroom.github.com/a/G6CcV2ZX)
# Top Rating Attribution

Follow the instructions in the [PDF attached](CPSC%201520%20Assignment%203.pdf)

NOTE: If you want to test your assignment please take a look at [the automated tests](automated-tests-do-not-touch/README.md). These are run when you push your code up to GitHub as well.

rateyourmusic.com
and https://www.kaggle.com/datasets/michaelbryantds/top-5000-albums-of-all-time-rateyourmusiccom?resource=download

## Backend

This assignment requires you to have the "assignment-3-backend" running correctly.
Please refer to its' README.md file to see how to run it.
